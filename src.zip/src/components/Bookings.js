import React from "react";

export default function Bookings() {
  return <div className="b_con"></div>;
}
