import React from 'react'

export default function Nomatch() {
  return (
    <div>
        <h1>No Page Found</h1>
    </div>
  )
}
